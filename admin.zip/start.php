<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Oma-Angat Dashboard Login</title>
  <link rel="icon" href="../images/web-logo.png" type="icon type">
  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

  <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=poppins:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Montserrat:400,700'>
<link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     
      <link rel="stylesheet" href="css/login.css">
      <link rel="stylesheet" href="css/green.css">
     
  
</head>

<body>

  
<div class="container">
  <div class="info">
    <h1></h1><span>“Bringing The Best of Bicol’s Harvest To Your Doorstep - SHOP LOCAL SUPPORT FARMERS”</span>
  </div>
</div>

<div class="form">
<div class="thumbnail kyi"><img src="images/manager.png"/></div>
<div class="container">
  <div class="info">
    <h1></h1><span>Login as</span>
  </div>
</div>
  <form class="login-form" action="index.php" method="post">
    <input  type="submit"  name="submit" value="Seller" />
  </form>
  <form class="login-form" action="../index.php" method="post">
    <input  type="submit"  name="submit" value="Buyer" />
  </form>
  
</div>

  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
  <script src='js/index.js'></script>
  

    



</body>

</html>
